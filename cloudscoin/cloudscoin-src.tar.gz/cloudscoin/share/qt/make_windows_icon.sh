#!/bin/bash
# create multiresolution windows icon
ICON_SRC=../../src/qt/res/icons/cloudscoin.png
ICON_DST=../../src/qt/res/icons/cloudscoin.ico
convert ${ICON_SRC} -resize 16x16 cloudscoin-16.png
convert ${ICON_SRC} -resize 32x32 cloudscoin-32.png
convert ${ICON_SRC} -resize 48x48 cloudscoin-48.png
convert cloudscoin-16.png cloudscoin-32.png cloudscoin-48.png ${ICON_DST}

